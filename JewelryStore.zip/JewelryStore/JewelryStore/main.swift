//
//  main.swift
//  JewelryStore
//
//  Created by Noura Alowayid on 23/10/1444 AH.
//

import Foundation

print("Enter your Name: ")
var name = (readLine() ?? "user")
print("Welcome \(name)")
print("What do you want to buy? Enter the number from the list:")
let categories : [Int: String] = [1: "Chain",
                                  2: "Earrings",
                                  3: "Rings",
                                  4: "Pins",
                                  5: "Bracelets",
                                  6: "Necklace",
                                  7: "Locket",
                                  8: "Bangles",
                                  9: "Watch",
                                  10: "Stud" ]

print(categories as AnyObject)
var selected = Int(readLine()!)

//ENUM:
enum Rings{
case ring
case engagementRing
case weddingRing
}

//FIRST GROUP DIAMONDS CLASSES:
protocol Diamond{
    var price: Int { get }
    var caratWeight: Float { get }
    var numberOfDiamonds: Int { get }
    var hasWarranty: Bool { get }
    var diamondClarity: String { get }
   // required init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String)
    
}
public class diamondChain: Diamond{
    var price: Int
    
    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
}

public class diamondEarrings: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
}

private class diamondRings: Diamond{
    var price: Int
    var ringType: Rings
    
    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, ringType: Rings, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.ringType = ringType
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
}

class diamondPins: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
    
}

class diamondBracelets: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    var claspType: [String] = ["Box Clasp", "Lobster Claw Clasp", "Spring Ring Clasp"]
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String, claspType: [String]) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
        self.claspType = claspType
    }
}

class diamondNecklace: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
    
}

class diamondLocket: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
}

class diamondBangles: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    var claspType: [String] = ["Box Clasp", "Lobster Claw Clasp", "Spring Ring Clasp"]
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String, claspType: [String]) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
        self.claspType = claspType
    }
}

class diamondWatch: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
}

class DiamondStud: Diamond{
    var price: Int

    var caratWeight: Float
    
    var numberOfDiamonds: Int
    
    var hasWarranty: Bool
    
    var diamondClarity: String
    
    init(price: Int, caratWeight: Float, numberOfDiamonds: Int, hasWarranty: Bool, diamondClarity: String) {
        self.price = price
        self.caratWeight = caratWeight
        self.numberOfDiamonds = numberOfDiamonds
        self.hasWarranty = hasWarranty
        self.diamondClarity = diamondClarity
    }
    
}
//OBJECTS:
let myChain = diamondChain(price: 10800, caratWeight: 17, numberOfDiamonds: 32, hasWarranty: true, diamondClarity: "VS1")
let myEarrings = diamondEarrings(price: 2100, caratWeight: 5, numberOfDiamonds: 2, hasWarranty: true, diamondClarity: "SI")
fileprivate let myRing = diamondRings(price: 6800, ringType: .engagementRing, caratWeight: 1.5, numberOfDiamonds: 1, hasWarranty: true, diamondClarity: "vs" )
let myPin = diamondPins(price: 3200, caratWeight: 9, numberOfDiamonds: 7, hasWarranty: true, diamondClarity: "VS1")
let myBracelets = diamondBracelets(price: 9700, caratWeight: 18, numberOfDiamonds: 3, hasWarranty: true, diamondClarity: "VS1", claspType: ["Box Clasp"])
let myNecklace = diamondNecklace(price: 9600, caratWeight: 9, numberOfDiamonds: 1, hasWarranty: true, diamondClarity: "VS")
let myBangles = diamondBangles(price: 10500, caratWeight: 19, numberOfDiamonds: 3, hasWarranty: true, diamondClarity: "VS1", claspType: ["Box Clasp"])
let myLocket = diamondLocket(price: 2450, caratWeight: 7, numberOfDiamonds: 1, hasWarranty: true, diamondClarity: "VS")
let myWatch = diamondWatch(price: 32000, caratWeight: 24, numberOfDiamonds: 12, hasWarranty: true, diamondClarity: "VS1")
let myStud = DiamondStud(price: 1500, caratWeight: 8, numberOfDiamonds: 32, hasWarranty: true, diamondClarity: "VS")

//USER INPUT
if selected == 1{
    dump(myChain)
} else if selected == 2 {
    dump(myEarrings)
} else if selected == 3 {
    dump(myRing)
} else if selected == 4 {
    dump(myPin)
} else if selected == 5 {
    dump(myBracelets)
} else if selected == 6 {
    dump(myNecklace)
} else if selected == 7 {
    dump(myBangles)
} else if selected == 8{
    dump(myLocket)
} else if selected == 9{
    dump(myWatch)
} else if selected == 10{
    dump(myStud)
}
//struct
struct Karat{
    var karat: [Int] = [18, 21, 24]
}

//class:
class ChainClaspType{
    var fType = "Box Clasp"
    var sType = "Lobster Claw Clasp"
    var tType = "Spring Ring Clasp"
    
    init(fType: String = "Box Clasp", sType: String = "Lobster Claw Clasp", tType: String = "Spring Ring Clasp") {
        self.fType = fType
        self.sType = sType
        self.tType = tType
    }
    
}

//SECOND GROUP YESLLOW GOLD CLASSES:
protocol YellowGold{
    var caratGold: Karat { get }
    var Weight: Double { get }
    var hasWarranty: Bool { get }

}

public class YellowChain: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    var chainClasp: ChainClaspType
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool, chainClasp: ChainClaspType) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
        self.chainClasp = chainClasp
    }

}
public class YellowEarrings: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

    
}

private class YellowRings: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class YellowPins: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

    
}

class YellowBracelets: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
}

class YellowNecklace: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class YellowLocket: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class YellowBangles: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
}

class YellowWatch: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

}

class YellowStud: YellowGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}



//THIRD GROUP WHITE GOLD CLASSES:
protocol WhiteGold{
    var caratGold: Karat { get }
    var Weight: Double { get }
    var hasWarranty: Bool { get }

}

public class WhiteChain: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

}
public class WhiteEarrings: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

    
}

private class WhiteRings: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class WhitePins: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

    
}

class WhiteBracelets: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
}

class WhiteNecklace: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class WhiteLocket: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}

class WhiteBangles: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
}

class WhiteWatch: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }

}

class WhiteStud: WhiteGold{
    var caratGold: Karat
    
    var Weight: Double
    
    var hasWarranty: Bool
    
    init(caratGold: Karat, Weight: Double, hasWarranty: Bool) {
        self.caratGold = caratGold
        self.Weight = Weight
        self.hasWarranty = hasWarranty
    }
    
}


//All swift keywords in an array:
let swiftKeywords: [String] = [
  "as",
  "break",
  "case",
  "catch",
  "class",
  "continue",
  "default",
  "do",
  "else",
  "enum",
  "extension",
  "fallthrough",
  "for",
  "func",
  "if",
  "import",
  "in",
  "init",
  "let",
  "guard",
  "if",
  "import",
  "in",
  "init",
  "let",
  "repeat",
  "return",
  "struct",
  "switch",
  "where",
  "while",
  "willSet",
  "with",
  "withoutActuallyEscaping",
  "yield",
]
